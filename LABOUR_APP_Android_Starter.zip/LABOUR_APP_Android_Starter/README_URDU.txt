LABOUR APP — Android Starter Project

IMPORTANT:
Yeh aapki bheji hui LABOUR APP.html file ko Android WebView mein kholne wala starter project hai.
Yeh abhi production-ready app NAHI hai.

HTML prototype ki limitations:
- OTP screen par demo hota hai; real SMS nahi bhejta.
- Data browser/session mein rehta hai; real online database nahi.
- CNIC/selfie verification automatic ya NADRA-verified nahi hai.
- Admin demo code ko secure production authentication nahi samjhein.
- Is project mein backend server abhi included nahi hai.

APK banane ka tareeqa:
1. Computer par Android Studio install karein.
2. Is ZIP ko extract karein.
3. Android Studio mein extracted LABOUR_APP folder ko Open karein.
4. Gradle sync complete hone dein.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) select karein.
6. APK app/build/outputs/apk/debug/ ke andar milegi.

Agar build error aaye to error ka screenshot bhejein.

Complete public launch se pehle:
- Secure backend/API aur production database
- Real SMS OTP provider and rate limiting
- Server-side login, authorization, admin roles
- Private identity-document storage and access controls
- Privacy policy, consent, retention/deletion process
- Hiring notifications, monitoring, backups, security testing
- Release signing and Play Store checks
zaroori hain.

Is starter ko public users ke CNIC, selfies ya real private data ke liye abhi use na karein.
